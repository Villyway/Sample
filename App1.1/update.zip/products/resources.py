from import_export import resources
from .models import Product

class ProductResource(resources.ModelResource):
    class Meta:
        model = Product
        fields = ("part_no","name",'category__name',"stock")
        export_order = ("part_no","name", "category__name","stock")